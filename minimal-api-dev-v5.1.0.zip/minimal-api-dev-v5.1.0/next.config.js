module.exports = {
  reactStrictMode: true,
  env: {
    DEV_API: 'http://localhost:3000',
    PRODUCTION_API: 'https://api-dev-minimal-v510.vercel.app',
  },
};
