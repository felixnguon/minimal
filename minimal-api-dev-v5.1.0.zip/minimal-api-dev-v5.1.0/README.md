# MOCK API SETUP GUIDE

https://docs.minimals.cc/quick-start
